import os
print("DOWNLOAD...........")
os.system("pip install pyTelegramBotAPI")
os.system("pip install DDos")
os.system("chmod +x bgmi")